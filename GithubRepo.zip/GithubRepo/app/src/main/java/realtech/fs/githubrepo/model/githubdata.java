package realtech.fs.githubrepo.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class githubdata {
    @SerializedName("name")
    private String name;
    private String forks;
    private String stars;
    private String avatar;
    private String author;
    private String description;
    private String language;
    private String languageColor;
    private String url;

    @Expose
    private boolean expandable;



    public githubdata(String name, String forks, String stars, String avatar, String author, String description, String language, String languageColor, String url) {
        this.name = name;
        this.forks = forks;
        this.stars = stars;
        this.avatar = avatar;
        this.author = author;
        this.description = description;
        this.language = language;
        this.languageColor = languageColor;
        this.url = url;
        this.expandable = false;

    }

    public boolean isExpandable() {
        return expandable;
    }

    public void setExpandable(boolean expandable) {
        this.expandable = expandable;
    }

    public String getName() {
        return name;
    }

    public String getForks() {
        return forks;
    }

    public String getStars() {
        return stars;
    }

    public String getAvatar() {
        return avatar;
    }

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public String getLanguage() {
        return language;
    }

    public String getLanguageColor() {
        return languageColor;
    }

    public String getUrl() {
        return url;
    }
}
