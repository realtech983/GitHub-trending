package realtech.fs.githubrepo.Interface;

import java.util.List;

import realtech.fs.githubrepo.model.githubdata;
import retrofit2.Call;
import retrofit2.http.GET;

public interface API {
    String BASE_URL = "https://private-d570e4-githubtrendingapi.apiary-mock.com/";



    @GET("repositories")
    Call<List<githubdata>> getHeroes();
}
