package realtech.fs.githubrepo.Adapter;


import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import realtech.fs.githubrepo.R;
import realtech.fs.githubrepo.model.githubdata;



public class GithubDataAdapter extends RecyclerView.Adapter<GithubDataAdapter.GithubDataVH> {

    List<githubdata> repolist;

    public GithubDataAdapter(List<githubdata> repolist) {
        this.repolist = repolist;
    }

    @NonNull
    @Override
    public GithubDataVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);


        return new GithubDataVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GithubDataVH holder, int position) {

        githubdata data = repolist.get(position);
        holder.author.setText(data.getAuthor());
        holder.name.setText(data.getName());
        holder.description.setText(data.getDescription());
        holder.language.setText(data.getLanguage());
        holder.star.setText(data.getStars());
        holder.fork.setText(data.getForks());
        Glide.with(holder.avtar.getContext()).load(data.getAvatar()).into(holder.avtar);
        holder.langaugeColor.setColorFilter(Color.parseColor(data.getLanguageColor()));


    boolean isExpandable = repolist.get(position).isExpandable();
       holder.relativeLayout.setVisibility(isExpandable?View.VISIBLE:View.GONE);

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.relativeLayout.isShown()) {
                    repolist.get(holder.getLayoutPosition()).setExpandable(false);
                } else {
                    repolist.get(holder.getLayoutPosition()).setExpandable(true);
                    changeStateOfItemsInLayout(repolist.get(holder.getLayoutPosition()),holder.getLayoutPosition());
                }
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return repolist.size();
    }

    private void changeStateOfItemsInLayout(githubdata listItem, int p) {
        for (int x = 0; x < repolist.size(); x++) {
            if (x == p) {
                listItem.setExpandable(true);
                //Since this is the tapped item, we will skip
                //the rest of loop for this item and set it expanded
                continue;
            }
            repolist.get(x).setExpandable(false);
        }
    }



    public class GithubDataVH extends RecyclerView.ViewHolder {
        TextView author,name,description,language,fork,star;
        ImageView avtar,langaugeColor;

        LinearLayout linearLayout;

        RelativeLayout relativeLayout;

        public GithubDataVH(@NonNull View itemView) {
            super(itemView);

            author = (TextView)itemView.findViewById(R.id.author_name);
            name = itemView.findViewById(R.id.name);
            description = itemView.findViewById(R.id.decription);
            language = itemView.findViewById(R.id.language_text_view);
            fork = itemView.findViewById(R.id.fork_text_view);
            star = itemView.findViewById(R.id.star_text_view);
            avtar = itemView.findViewById(R.id.avtar);
            langaugeColor = itemView.findViewById(R.id.langauge_image_view);

            linearLayout = itemView.findViewById(R.id.main_linear_layout);
            relativeLayout = itemView.findViewById(R.id.expand_view);

//            linearLayout.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//
//                    githubdata gdata = repolist.get(getAdapterPosition());
//                    gdata.setExpandable(!gdata.isExpandable());
//                    notifyItemChanged(getAdapterPosition());
//                }
//            });
        }
    }
}
