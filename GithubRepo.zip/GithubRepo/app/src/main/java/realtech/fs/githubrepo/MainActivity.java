package realtech.fs.githubrepo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import realtech.fs.githubrepo.Adapter.GithubDataAdapter;
import realtech.fs.githubrepo.Interface.API;
import realtech.fs.githubrepo.Utils.utils;
import realtech.fs.githubrepo.model.githubdata;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<githubdata> gdata;
    private SwipeRefreshLayout swipeRefreshLayout;
    Retrofit retrofit;
    final GithubDataAdapter[] githubDataAdapter = new GithubDataAdapter[1];
    ProgressBar progressBar;


    private RelativeLayout errorLayout;
    private ImageView errorImage;
    private TextView erroTitle,errorMessage;
    private Button btnRetry;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView =  findViewById(R.id.recyclerView);
        swipeRefreshLayout = findViewById(R.id.swiperefresh);
        progressBar = findViewById(R.id.progress_circular);

        errorLayout = findViewById(R.id.error_layout);
        errorImage = findViewById(R.id.errorImage);
        errorMessage = findViewById(R.id.errorMessage);
        erroTitle = findViewById(R.id.errorTitle);
        btnRetry = findViewById(R.id.retry_btn);




        Context context = getApplication();

        OkHttpClient client = new OkHttpClient
                .Builder()
                .cache(new Cache(getCacheDir(), 10 * 1024 * 1024)) // 10 MB
                .addInterceptor(new Interceptor() {
                    @Override public okhttp3.Response intercept(Chain chain) throws IOException {
                        Request request = chain.request();
                        if (utils.isNetworkAvailable(context)) {
                            request = request.newBuilder().header("Cache-Control", "public, max-age=" + 60).build();
                        } else {
                            request = request.newBuilder().header("Cache-Control", "public, only-if-cached, max-stale=" + 60*15).build();
                        }
                        return chain.proceed(request);
                    }
                })
                .build();

        retrofit = new Retrofit.Builder()
                .baseUrl(API.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        getData();

        onswipeRefresh();


    }

    private void onswipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getData();
            }
        });
    }

    public void getData()
    {
        errorLayout.setVisibility(View.GONE);
        API api = retrofit.create(API.class);

        Call<List<githubdata>> call = api.getHeroes();

        call.enqueue(new Callback<List<githubdata>>() {
            @Override
            public void onResponse(Call<List<githubdata>> call, Response<List<githubdata>> response) {

                progressBar.setVisibility(View.GONE);
                if(response.isSuccessful() && response.body().isEmpty() == false) {

                    gdata = response.body();


                    githubDataAdapter[0] = new GithubDataAdapter(gdata);
                    recyclerView.setAdapter(githubDataAdapter[0]);

                    swipeRefreshLayout.setRefreshing(false);
                }
                else {
                    swipeRefreshLayout.setRefreshing(false);
                    String errorcode;
                    switch (response.code())
                    {
                        case 404:
                            errorcode = "404 not found";
                            break;
                        case 500:
                            errorcode = "500 server broken";
                        default:
                            errorcode = "unknown error";
                            break;

                    }
                    showErrorMessage(R.drawable.nointernet_connection, "no result ","Please Retry Again\n"+errorcode);

                }


            }

            @Override
            public void onFailure(Call<List<githubdata>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                showErrorMessage(R.drawable.nointernet_connection, "Oops... ","Network failure Please Retry Again\n"+t.toString());

            }
        });
    }

    private void showErrorMessage(int imageView,String title,String message)
    {
        if(errorLayout.getVisibility() == View.GONE)
            errorLayout.setVisibility(View.VISIBLE);

        errorImage.setImageResource(imageView);
        erroTitle.setText(title);
        errorMessage.setText(message);
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
               getData();
            }
        });

    }
}